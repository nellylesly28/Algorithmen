#pragma once

#include <string>
#include <vector>

class Diff {
public: // methods

	static std::vector<unsigned> shortestPaths(const std::vector<std::string>& a,const std::vector<std::string>& b);
};
