#pragma once
#ifndef _COMPRESS_H
#define _COMPRESS_H


void bitDot(Huffman::TreeNBitVector& daten, std::ostream& os);

#endif 
